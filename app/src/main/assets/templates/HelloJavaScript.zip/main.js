
console.log("Hello World");